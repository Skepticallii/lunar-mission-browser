"""
Turn a huge LOLA DEM into small, commit-able terrain products around one site.

    python preprocessing/make_terrain_products.py \
        --dem LOLA_Data/LM1_final_adj_5mpp_surf.tif \
        --name lm1 --lat -89.5244 --lon 56.30993 --radius 2500

Reads only the window it needs (rasterio windowed read), so memory stays small even
for multi-GB rasters. Outputs go to terrain/ :

    <name>_terrain.npz   height_m (relative to the site), slope_deg  - float32 grids
    <name>_terrain.json  metadata: grid size, metres/pixel, site elevation, CRS, slope stats
    <name>_terrain.png   quick-look hillshade + slope preview

Slope is computed at the DEM's NATIVE resolution first and then block-averaged, so the
coarser output grid does not hide steep small-scale terrain. Slope still depends on DEM
resolution - always quote the resolution next to any slope number.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import rasterio
from pyproj import CRS, Transformer
from rasterio.windows import Window

MOON_RADIUS = 1_737_400.0


def block_mean(a: np.ndarray, f: int) -> np.ndarray:
    """Average f x f blocks, ignoring NaNs."""
    h, w = (a.shape[0] // f) * f, (a.shape[1] // f) * f
    b = a[:h, :w].reshape(h // f, f, w // f, f)
    with np.errstate(all="ignore"):
        return np.nanmean(b, axis=(1, 3))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dem", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--lat", type=float, required=True)
    ap.add_argument("--lon", type=float, required=True, help="east-positive degrees")
    ap.add_argument("--radius", type=float, default=2500.0, help="half-width of the cutout in metres")
    ap.add_argument("--max-grid", type=int, default=512, help="max output grid size (pixels per side)")
    ap.add_argument("--out", default="terrain")
    a = ap.parse_args()

    geographic = CRS.from_proj4(f"+proj=longlat +R={MOON_RADIUS} +type=crs")
    with rasterio.open(a.dem) as src:
        if src.crs is not None:
            projected = src.crs
            crs_note = f"taken from the GeoTIFF: {src.crs.to_string()[:80]}"
        else:
            projected = CRS.from_proj4(f"+proj=stere +lat_0=-90 +lon_0=0 +R={MOON_RADIUS} +units=m +type=crs")
            crs_note = "ASSUMED polar stereographic (GeoTIFF has no CRS) - needs scientific validation"
        print("CRS:", crs_note)

        x, y = Transformer.from_crs(geographic, projected, always_xy=True).transform(a.lon, a.lat)
        if not (src.bounds.left <= x <= src.bounds.right and src.bounds.bottom <= y <= src.bounds.top):
            raise SystemExit("Site is outside the DEM - nothing written.")

        px = abs(src.res[0])
        py = abs(src.res[1])
        row0, col0 = src.index(x, y)
        half = int(round(a.radius / px))
        r0, c0 = max(0, row0 - half), max(0, col0 - half)
        r1, c1 = min(src.height, row0 + half + 1), min(src.width, col0 + half + 1)
        z = src.read(1, window=Window(c0, r0, c1 - c0, r1 - r0), masked=True).astype("float64").filled(np.nan)
        site_z = float(src.read(1, window=Window(col0, row0, 1, 1), masked=True).astype("float64").filled(np.nan)[0, 0])
        if not np.isfinite(site_z):
            raise SystemExit("Site elevation is missing in the DEM.")

    print(f"Window: {z.shape[1]} x {z.shape[0]} px at {px:g} m/px, "
          f"missing {100 * np.isnan(z).mean():.2f}%")

    # slope at native resolution
    dzdy, dzdx = np.gradient(z, py, px)
    slope = np.degrees(np.arctan(np.hypot(dzdx, dzdy)))

    f = max(1, int(np.ceil(max(z.shape) / a.max_grid)))
    height = (block_mean(z, f) - site_z).astype("float32")
    slope_c = block_mean(slope, f).astype("float32")
    mpp = px * f

    stats = {f"area_below_{t}deg_pct": round(float(100 * np.nanmean(slope < t)), 2) for t in (5, 10, 15, 20)}
    meta = {
        "name": a.name, "lat": a.lat, "lon": a.lon,
        "grid_px": [int(height.shape[1]), int(height.shape[0])],
        "metres_per_pixel": mpp, "source_metres_per_pixel": px,
        "site_elevation_m": site_z,
        "relief_min_m": float(np.nanmin(height)), "relief_max_m": float(np.nanmax(height)),
        "slope_stats_native_resolution": stats,
        "crs": crs_note, "dem_file": Path(a.dem).name,
        "note": "height_m is relative to the site. Slope computed at native resolution, then block-averaged.",
    }

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out / f"{a.name}_terrain.npz", height_m=height, slope_deg=slope_c)
    (out / f"{a.name}_terrain.json").write_text(json.dumps(meta, indent=2))

    try:  # quick-look preview
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        gy, gx = np.gradient(np.nan_to_num(height), mpp)
        shade = np.clip(0.5 + 3 * (gx * 0.7 - gy * 0.7), 0, 1)       # simple oblique hillshade
        fig, ax = plt.subplots(1, 2, figsize=(11, 5))
        ax[0].imshow(shade, cmap="gray"); ax[0].set_title("Hillshade")
        im = ax[1].imshow(slope_c, cmap="magma", vmin=0, vmax=25); ax[1].set_title("Slope (deg)")
        fig.colorbar(im, ax=ax[1], shrink=0.8)
        for k in ax:
            k.plot(shade.shape[1] / 2, shade.shape[0] / 2, "c+", ms=14); k.set_xticks([]); k.set_yticks([])
        fig.tight_layout(); fig.savefig(out / f"{a.name}_terrain.png", dpi=120); plt.close(fig)
    except ImportError:
        pass

    size_kb = (out / f"{a.name}_terrain.npz").stat().st_size / 1024
    print(f"Saved {out}/{a.name}_terrain.* ({height.shape[1]}x{height.shape[0]} grid at {mpp:g} m/px, "
          f"{size_kb:.0f} KB)")
    print("Slope stats:", stats)


if __name__ == "__main__":
    main()